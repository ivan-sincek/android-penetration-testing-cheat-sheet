### v1.4 

- Returning the module to my own personal repo for now after androidacy issues.

### v1.5

- Preparing for move to new repo (Bye XDA - i will no longer link my work from a place where mods protect people who mock people with disabilities (a pattern sadly))
- Adding back update.json and change to module.prop as necessary
